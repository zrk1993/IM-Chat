<template>
    <div>
      <h2>添加好友</h2>
    </div>
</template>

<script>

export default {
  name: 'hello',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  components:{
  }
}
</script>

