<template>
  <div>
    <ul class="m_operations">
      <li><i class="iconfont icon-fankui f_hui_s f_fs12 f_mx10"></i><span>添加好友</span></li>
      <li><i class="iconfont icon-101 f_hui_s f_fs12 f_mx10"></i><span>好友黑名单</span></li>
      <li><i class="iconfont icon-fankui f_hui_s f_fs12 f_mx10"></i><span>创建群组</span></li>
      <li><i class="iconfont icon-tuichu f_hui_s f_fs12 f_mx10"></i><span>退出(renkun123)</span></li></ul>
  </div>
</template>

<script>
export default {
  name: 'webim-operations',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

